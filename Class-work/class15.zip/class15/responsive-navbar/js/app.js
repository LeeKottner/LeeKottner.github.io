$(document).ready(function () {
	// console.log($(window).width());

})
